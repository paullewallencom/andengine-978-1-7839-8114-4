/** Automatically generated file. DO NOT MODIFY */
package com.nyanko.andengineontour;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}